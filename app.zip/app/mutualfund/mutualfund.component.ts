import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { Router } from '@angular/router';
import { MutualFund, Account } from '../details';
import { Usermodel } from '../user';
import { stringify } from '@angular/compiler/src/util';

@Component({
  selector: 'app-mutualfund',
  templateUrl: './mutualfund.component.html',
  styleUrls: ['./mutualfund.component.css']
})
export class MutualfundComponent implements OnInit {

  abc: any;
  isLoggedIn:boolean = false;
  panNo:string;
  token:string;
  username:string;
  accountNo:string;
  funddetails :MutualFund = new MutualFund();

  
  constructor(private userService:UserserviceService,private route : Router) { }
  
  user : Usermodel = new Usermodel();
  account : Account = new Account(this.user);
  ngOnInit(): void {
    this.panNo = window.localStorage.getItem('panNo');
    this.token = window.localStorage.getItem('token');
    this.username = window.localStorage.getItem('username');
    this.funddetails.fundId = window.localStorage.getItem('fundId');
    window.localStorage.setItem("panNo",this.panNo);
    if(this.token != null && this.token.length > 10){
      this.isLoggedIn = true;
    }
  }
  fundId:string;
  onFormSubmit(){

    // this.userService.createAccount(this.account).subscribe(data => console.log(data), error => console.log(error));
    // alert("Account Created");
    //  this.route.navigateByUrl("/dashboard");
    // //this.myForm.reset();
    
    const uploadProductData = new FormData();
    uploadProductData.append('fundId', this.funddetails.fundId);
    uploadProductData.append('fundName', this.funddetails.fundName);
    uploadProductData.append('amount',this.funddetails.amount); //this.sellerId
    uploadProductData.append('panNo', this.panNo = window.localStorage.getItem('panNo'));
    uploadProductData.append('accountNo', this.account.accountNo);
    console.log("data");
    console.log(uploadProductData.get('funddetails'));
    this.userService.createMf(uploadProductData).subscribe((response) => {
             if (response.status === 200) {
          //    window.localStorage.setItem('fundId', response.result.fundId);
          
               alert("Product added Successfully");
            } else {
              alert("adding Product failed Try Again");
            }

   }
 
  
    );
    alert("Product Added to Fund Id: ");
    this.route.navigateByUrl("/dashboard");
}

}
